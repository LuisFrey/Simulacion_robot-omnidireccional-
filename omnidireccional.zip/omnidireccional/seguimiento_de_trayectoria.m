% Parámetros del robot
r = 0.05; % radio de la rueda en metros
L = 0.2; % distancia entre ejes en metros

% Datos de los encoders
v1 = 0.5; % velocidad angular de la rueda 1 en rad/s
v2 = 0.3; % velocidad angular de la rueda 2 en rad/s
v3 = 0.2; % velocidad angular de la rueda 3 en rad/s
v4 = 0.4; % velocidad angular de la rueda 4 en rad/s

% Calcular las velocidades lineales de cada rueda
w1 = v1*r;
w2 = v2*r;
w3 = v3*r;
w4 = v4*r;

% Calcular las velocidades lineales y angulares del robot
vx = (r/4)*(w1 + w2 + w3 + w4);
vy = (r/(2*L))*(-w1 + w2 + w3 - w4);
wz = (r/(4*L))*(-w1 + w2 - w3 + w4);

% Simular el movimiento del robot


% Visualizar la trayectoria del robot
plot(x,y);
xlabel('x');
ylabel('y');
title('Trayectoria del robot omnidireccional de 4 ruedas');